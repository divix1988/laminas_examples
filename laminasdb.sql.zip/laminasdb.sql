-- phpMyAdmin SQL Dump
-- version 5.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Czas generowania: 02 Lis 2020, 22:17
-- Wersja serwera: 10.4.11-MariaDB
-- Wersja PHP: 7.4.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Baza danych: `laminasdb`
--

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `comics`
--

CREATE TABLE `comics` (
  `id` int(10) UNSIGNED NOT NULL,
  `title` varchar(200) NOT NULL,
  `thumb` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Zrzut danych tabeli `comics`
--

INSERT INTO `comics` (`id`, `title`, `thumb`) VALUES
(1, 'batman', 'bat.png'),
(2, 'spiderman', 'spider.jpg'),
(3, 'updated thor22', 'second.png'),
(4, 'updated hulk3', ''),
(5, 'captain america', 'captain.jpg'),
(7, 'blah', 'aaa');

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `newusers`
--

CREATE TABLE `newusers` (
  `id` int(11) NOT NULL,
  `username` varchar(100) NOT NULL,
  `password` char(128) DEFAULT NULL,
  `password_salt` varchar(8) DEFAULT NULL,
  `name` varchar(200) DEFAULT NULL,
  `email` varchar(100) NOT NULL,
  `gender` varchar(10) NOT NULL,
  `education` varchar(50) NOT NULL,
  `role` varchar(20) NOT NULL DEFAULT 'user'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Zrzut danych tabeli `newusers`
--

INSERT INTO `newusers` (`id`, `username`, `password`, `password_salt`, `name`, `email`, `gender`, `education`, `role`) VALUES
(1, 'some_username2', 'plain_pass', NULL, NULL, '', '', '', 'user'),
(2, 'divix', 'another_pass', NULL, NULL, '', '', '', 'user'),
(3, 'abc', 'some_some', NULL, NULL, '', '', '', 'user'),
(6, 'dsa', '', NULL, NULL, '', '', '', 'user'),
(7, 'divix1988', '', NULL, NULL, 'info@funkcje.net', 'male', 'primary', 'user'),
(13, 'divix1234', 'c97d70c1be59cf4934c81e0509f326601ecaf2da726ea4a58454ad9f7a11055917ebe763c5139b462bf497a1aba31ff2c31864d55914e114165fa78445489d26', 'cvwg', NULL, 'infoz2@funkcje.net', '', '', 'user'),
(14, 'divix12345', 'a7e7649c1f0cfc751d87fbce86401baf8161b5bb8842fda927835f042c4326bd36f3131c3e21f721138dc49dcc8025ba86f7429601980f5fca4b917bb18b7e38', 'uzhkn', NULL, 'infoz24@funkcje.net', '', '', 'super_admin'),
(15, 'aaa', NULL, NULL, NULL, 'info@funkcje.net', '', '', 'user'),
(16, '111', NULL, NULL, NULL, 'info22@funkcje.net', '', '', 'user');

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `pages`
--

CREATE TABLE `pages` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(40) CHARACTER SET utf8 NOT NULL,
  `url` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `parent_id` int(11) NOT NULL DEFAULT 0,
  `required` tinyint(4) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Zrzut danych tabeli `pages`
--

INSERT INTO `pages` (`id`, `name`, `url`, `parent_id`, `required`) VALUES
(1, 'Footer', 'footer', 0, 1),
(2, 'Test Article', 'test_article', 0, 0);

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `pages2`
--

CREATE TABLE `pages2` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(40) CHARACTER SET utf8 NOT NULL,
  `url` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `parent_id` int(11) NOT NULL DEFAULT 0,
  `required` tinyint(4) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Zrzut danych tabeli `pages2`
--

INSERT INTO `pages2` (`id`, `name`, `url`, `parent_id`, `required`) VALUES
(1, 'aaa', 'www', 0, 0);

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `page_contents`
--

CREATE TABLE `page_contents` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(100) CHARACTER SET utf8 NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Zrzut danych tabeli `page_contents`
--

INSERT INTO `page_contents` (`id`, `name`) VALUES
(1, 'footer_contents'),
(2, 'test_article_contents');

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `page_lang_contents`
--

CREATE TABLE `page_lang_contents` (
  `id` int(10) UNSIGNED NOT NULL,
  `lang` varchar(2) CHARACTER SET utf32 NOT NULL,
  `content` text CHARACTER SET utf8 NOT NULL,
  `page_content_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Zrzut danych tabeli `page_lang_contents`
--

INSERT INTO `page_lang_contents` (`id`, `lang`, `content`, `page_content_id`) VALUES
(1, 'en', 'Custom footer from CMS', 1),
(2, 'en', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Quisque magna diam, facilisis vitae felis vel, porttitor dignissim elit. Phasellus dapibus urna urna, ut eleifend nibh malesuada at. Cras congue a ex ut dictum. Praesent rhoncus nunc eget magna semper viverra. Nulla facilisis arcu non elementum tincidunt. Donec scelerisque sem at varius suscipit. Nunc venenatis ac neque vel feugiat. Nunc condimentum dolor tortor, et molestie tortor rhoncus at.\r\n\r\nAliquam porta vitae ligula a feugiat. Proin sodales pulvinar diam, id maximus nisi posuere vitae. Integer sollicitudin, diam vel consectetur egestas, neque erat ultricies ligula, quis congue metus sapien sed enim. Nulla facilisi. Donec ultricies eget ligula nec egestas. In lobortis massa eu mi aliquet, vel porttitor ex auctor. Nunc pulvinar blandit neque a cursus. Nunc dapibus dolor tempor lorem auctor malesuada. Sed tempus diam ut odio pulvinar sodales.', 2);

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `page_metadata`
--

CREATE TABLE `page_metadata` (
  `id` int(10) UNSIGNED NOT NULL,
  `lang` varchar(3) CHARACTER SET latin1 NOT NULL,
  `title` varchar(100) NOT NULL,
  `description` varchar(100) NOT NULL,
  `keywords` varchar(150) NOT NULL,
  `page_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Zrzut danych tabeli `page_metadata`
--

INSERT INTO `page_metadata` (`id`, `lang`, `title`, `description`, `keywords`, `page_id`) VALUES
(1, 'en', 'Test Article', 'Some dummy article from DB', 'article, db, laminas, cool', 2);

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `page_to_contents`
--

CREATE TABLE `page_to_contents` (
  `id` int(10) UNSIGNED NOT NULL,
  `page_id` int(11) NOT NULL,
  `content_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Zrzut danych tabeli `page_to_contents`
--

INSERT INTO `page_to_contents` (`id`, `page_id`, `content_id`) VALUES
(1, 1, 1),
(2, 2, 2);

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(100) NOT NULL,
  `password` char(128) DEFAULT NULL,
  `password_salt` varchar(8) DEFAULT NULL,
  `name` varchar(200) DEFAULT NULL,
  `email` varchar(100) NOT NULL,
  `gender` varchar(10) NOT NULL,
  `education` varchar(50) NOT NULL,
  `role` varchar(20) NOT NULL DEFAULT 'user'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Zrzut danych tabeli `users`
--

INSERT INTO `users` (`id`, `username`, `password`, `password_salt`, `name`, `email`, `gender`, `education`, `role`) VALUES
(1, 'some_username2', 'plain_pass', NULL, NULL, '', '', '', 'user'),
(2, 'divix', 'another_pass', NULL, NULL, '', '', '', 'user'),
(3, 'abc', 'some_some', NULL, NULL, '', '', '', 'user'),
(6, 'dsa', '', NULL, NULL, '', '', '', 'user'),
(7, 'divix1988', '', NULL, NULL, 'info@funkcje.net', 'male', 'primary', 'user'),
(13, 'divix1234', 'c97d70c1be59cf4934c81e0509f326601ecaf2da726ea4a58454ad9f7a11055917ebe763c5139b462bf497a1aba31ff2c31864d55914e114165fa78445489d26', 'cvwg', NULL, 'infoz2@funkcje.net', '', '', 'user'),
(14, 'divix12345', 'a7e7649c1f0cfc751d87fbce86401baf8161b5bb8842fda927835f042c4326bd36f3131c3e21f721138dc49dcc8025ba86f7429601980f5fca4b917bb18b7e38', 'uzhkn', NULL, 'infoz24@funkcje.net', '', '', 'super_admin'),
(15, 'aaa', NULL, NULL, NULL, 'info@funkcje.net', '', '', 'user'),
(16, '111', NULL, NULL, NULL, 'info22@funkcje.net', '', '', 'user'),
(17, 'info6', '5987cfa8d5d88894ba181e5f9cdbcb4b2b2bb26619db0bb40229da1abb27a11c351834cdbffed7198a15384742d20cad72343711226508826ad994fd56b728da', 'M4aiwE', NULL, 'info6@funkcje.net', '', '', 'user'),
(18, 'info7', '23ba71a13c3c5546407e4fccde1a62dbde91b2ab735d623b67dff517cf79b0f98ff2b129051b821c21d2e42b3763e30ec4b8c3da7817acfd1a6ce9e9570489bf', 'WgJtDP', NULL, 'info7@funkcje.net', '', '', 'user'),
(19, 'info8', '075a1131d225ddef7bc986d12c9aae380e320e4723af0563c6e23344c3bfe73a49ae160efe66418b779c54146123704fdfdb1752a72a562e82198cb9f6ea7360', 'WwVFuvSy', NULL, 'info8@funkcje.net', '', '', 'user'),
(20, 'info9', 'd47e63a1a245978c17453281b6fd1687a3ac6635540523edcadfb63df4c9bb4f6bcdb926b40b122f422675b4054b20e97f716d586569e24e6f0e5a33dfb136d7', 'BuxNvKcY', NULL, 'info9@funkcje.net', '', '', 'user'),
(21, 'info10', '3f4c2041d27678a9fe763c6497002f7485204ffdbc41280bdf7decdf1cd378caf354474970e07e940ff4ac2a4f4a6c1c4748e01fd5058d81d0d2587b150f2dfc', 'ueHp', NULL, 'info10@funkcje.net', '', '', 'user'),
(22, 'info11', 'c7a9fd51157723ecb1e42fbf762ad20f4c027cb0ee5e2ca89bd1746ea087c24f256b499523d05ec61e5b66b1a4ed393b01410b2a8334e33ba331775163414f7a', '8bGw', NULL, 'info11@funkcje.net', '', '', 'user'),
(23, 'info12@funkcje.net', '7c8fb0528818fce3206987eb612805a1674954100e58be528e86d08493f99c10a80cd123856c1ee04fb5e577e95701362d22e36fd2ddb3d861c8181a13bfd075', 'q3Jra4h', NULL, 'info12@funkcje.net', '', '', 'user'),
(24, 'info13@funkcje.net', '2bc37c57d405b56290971bcd9a3a874a4510b224afedbfbf765a7669c27c3d956951c7e8cccb6bee1a60fd23d95c0daa1ddb8a9ab73ee9dd86e01a4308b2f7a9', 'jNaSu', NULL, 'info13@funkcje.net', '', '', 'user'),
(25, 'info30@funkcje.net', '9699d3916275ed94c5cf25057bb5b42ea16118d8e89c7582568ed49311b9501f67e06fb5e61f387c208d426e7f320fe753d1d4993e31c38bc85443e5f1f94eed', 'ATNu4', NULL, 'info30@funkcje.net', '', '', 'user');

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `user_hobbies`
--

CREATE TABLE `user_hobbies` (
  `id` int(10) UNSIGNED NOT NULL,
  `user_id` int(11) NOT NULL,
  `hobby` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Zrzut danych tabeli `user_hobbies`
--

INSERT INTO `user_hobbies` (`id`, `user_id`, `hobby`) VALUES
(0, 7, 'books'),
(0, 7, 'sport');

--
-- Indeksy dla zrzutów tabel
--

--
-- Indeksy dla tabeli `comics`
--
ALTER TABLE `comics`
  ADD PRIMARY KEY (`id`);

--
-- Indeksy dla tabeli `newusers`
--
ALTER TABLE `newusers`
  ADD PRIMARY KEY (`id`);

--
-- Indeksy dla tabeli `pages`
--
ALTER TABLE `pages`
  ADD PRIMARY KEY (`id`),
  ADD KEY `parent_id` (`parent_id`);

--
-- Indeksy dla tabeli `pages2`
--
ALTER TABLE `pages2`
  ADD PRIMARY KEY (`id`);

--
-- Indeksy dla tabeli `page_contents`
--
ALTER TABLE `page_contents`
  ADD PRIMARY KEY (`id`),
  ADD KEY `name` (`name`);

--
-- Indeksy dla tabeli `page_lang_contents`
--
ALTER TABLE `page_lang_contents`
  ADD PRIMARY KEY (`id`),
  ADD KEY `lang` (`lang`);

--
-- Indeksy dla tabeli `page_metadata`
--
ALTER TABLE `page_metadata`
  ADD PRIMARY KEY (`id`);

--
-- Indeksy dla tabeli `page_to_contents`
--
ALTER TABLE `page_to_contents`
  ADD PRIMARY KEY (`id`),
  ADD KEY `page_id` (`page_id`,`content_id`);

--
-- Indeksy dla tabeli `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT dla tabeli `comics`
--
ALTER TABLE `comics`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT dla tabeli `newusers`
--
ALTER TABLE `newusers`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT dla tabeli `pages`
--
ALTER TABLE `pages`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT dla tabeli `pages2`
--
ALTER TABLE `pages2`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT dla tabeli `page_contents`
--
ALTER TABLE `page_contents`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT dla tabeli `page_lang_contents`
--
ALTER TABLE `page_lang_contents`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT dla tabeli `page_metadata`
--
ALTER TABLE `page_metadata`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT dla tabeli `page_to_contents`
--
ALTER TABLE `page_to_contents`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT dla tabeli `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
